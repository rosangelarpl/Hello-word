function calcularAreaTriangulo(){

	var base=document.getElementById("base").value;
	var altura=document.getElementById("altura").value;
	base=base.toString().replace(',','.');
	altura=altura.toString().replace(',','.');

	if(base==""){
			//document.getElementById("errorTriangulo").innerHTML="Por favor, digite a base da figura.";
	}
	else if(base<0){
			//document.getElementById("errorTriangulo").innerHTML="base do triangulo não pode ser negativa.";
	}
	else{
			//document.getElementById("errorTriangulo").innerHTML="";
			if(altura==""){
				//document.getElementById("errorTriangulo").innerHTML="Por favor, digite a altura da figura";
			}
			else if(altura<0){
					//document.getElementById("errorTriangulo").innerHTML="altura do triangulo não pode ser negativa.";
			}
			else{
					//document.getElementById("errorTriangulo").innerHTML="";
					var area=0;
					area=parseInt(base) * parseInt(altura)/2;
					//alert(area);
					document.getElementById("area").value=Math.round(area*100)/100;
			}
	}
}
